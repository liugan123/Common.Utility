﻿using System;

namespace CSharp_Attribute
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Newtonsoft相关特性测试
            NewtonsoftTest.Test();
            #endregion


            Console.ReadKey();
        }
    }
}
